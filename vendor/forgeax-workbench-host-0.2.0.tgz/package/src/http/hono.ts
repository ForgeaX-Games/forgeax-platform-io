import { Hono } from "hono"

import { createWorkbenchHttpHandler, isBodylessStatus, MAX_WORKBENCH_REQUEST_BODY_BYTES, stripMountPrefix, type WorkbenchHttpHost } from "./common.js"

async function readBounded(body: ReadableStream<Uint8Array> | null): Promise<{ readonly bytes: Uint8Array; readonly tooLarge: boolean }> {
  if (!body) return { bytes: new Uint8Array(), tooLarge: false }
  const reader = body.getReader(); const chunks: Uint8Array[] = []; let length = 0
  try { for (;;) { const next = await reader.read(); if (next.done) break; length += next.value.byteLength; if (length > MAX_WORKBENCH_REQUEST_BODY_BYTES) { await reader.cancel(); return { bytes: new Uint8Array(), tooLarge: true } }; chunks.push(next.value) } }
  finally { reader.releaseLock() }
  const bytes = new Uint8Array(length); let offset = 0; for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength }; return { bytes, tooLarge: false }
}

export interface HonoWorkbenchHostOptions { readonly prefix?: string }

/** Returns a raw-body router which is safe to mount beneath any Hono base path. */
export function createHonoWorkbenchRouter(host: WorkbenchHttpHost, options: HonoWorkbenchHostOptions = {}): Hono {
  const handler = createWorkbenchHttpHandler(host); const prefix = options.prefix ?? ""
  const app = new Hono()
  app.all("*", async (context) => {
    const raw = context.req.raw
    const body = await readBounded(raw.body)
    const response = await handler({ method: context.req.method, path: stripMountPrefix(new URL(context.req.url).pathname + new URL(context.req.url).search, prefix), headers: Object.fromEntries(raw.headers.entries()), body: body.tooLarge ? new Uint8Array(MAX_WORKBENCH_REQUEST_BODY_BYTES + 1) : body.bytes })
    const headers = new Headers()
    for (const [name, value] of Object.entries(response.headers)) {
      if (typeof value !== "string") for (const item of value) headers.append(name, item)
      else headers.set(name, value)
    }
    return new Response(context.req.method === "HEAD" || isBodylessStatus(response.status) ? null : response.body as unknown as BodyInit, { status: response.status, headers })
  })
  return app
}
