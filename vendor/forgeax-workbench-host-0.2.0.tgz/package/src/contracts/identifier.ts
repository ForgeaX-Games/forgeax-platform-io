/** Stable identifier grammar shared by untrusted tool and HTTP inputs. */
export function isWorkbenchIdentifier(value: string): boolean {
  return /^[\p{L}\p{N}_-]+$/u.test(value) && !value.startsWith(".") && !value.includes("%")
}
