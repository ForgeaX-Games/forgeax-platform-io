/** A host capability required by a tool or provided by an extension. */
export interface CapabilityRequirement {
  readonly id: string
  readonly version: number
}

/** A concrete extension-provided implementation of a host capability. */
export interface CapabilityProviderDescriptor extends CapabilityRequirement {
  readonly providerId: string
}

/** The provider selected by the host for one capability requirement. */
export interface CapabilitySelection extends CapabilityRequirement {
  readonly providerId: string
}
