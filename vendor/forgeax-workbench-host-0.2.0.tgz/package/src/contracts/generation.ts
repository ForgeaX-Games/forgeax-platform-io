import type {
  MediaAsset,
  MediaCapability,
  VideoGenerationInput,
  VideoGenerationResult,
} from "./adapters.js"
import type { ServiceCapability } from "./service-binding.js"

export type GenerationJobStatus =
  | "created"
  | "submitting"
  | "polling"
  | "output_pending_import"
  | "succeeded"
  | "failed"
  | "cancelled"

export interface GenerationJob {
  readonly jobId: string
  readonly status: GenerationJobStatus
  readonly progress?: number
  readonly assets?: readonly MediaAsset[]
  readonly error?: {
    readonly code: string
    readonly message: string
    readonly retryable: boolean
  }
  readonly createdAt: string
  readonly updatedAt: string
}

export interface ProviderMediaOutput {
  readonly serviceId: string
  readonly locator: string
  readonly filename: string
  readonly contentType: string
}

export interface ProviderExecutionContext {
  readonly gameId: string
  readonly traceId: string
  readonly media: MediaCapability
  readonly services: ServiceCapability
}

export type ProviderTaskStatus =
  | { readonly status: "polling"; readonly progress?: number }
  | { readonly status: "succeeded"; readonly outputs: readonly ProviderMediaOutput[] }
  | { readonly status: "failed"; readonly code: string; readonly message: string; readonly retryable: boolean }
  | { readonly status: "cancelled" }

export interface VideoGenerationProviderV1 {
  submit(
    context: ProviderExecutionContext,
    input: VideoGenerationInput,
  ): Promise<{ readonly providerTaskId: string }>
  query(
    context: ProviderExecutionContext,
    providerTaskId: string,
  ): Promise<ProviderTaskStatus>
  cancel?(
    context: ProviderExecutionContext,
    providerTaskId: string,
  ): Promise<void>
}

export interface VideoGenerationGateway {
  start(input: VideoGenerationInput): Promise<GenerationJob>
  get(jobId: string): Promise<GenerationJob>
  cancel(jobId: string): Promise<void>
  generateVideo(input: VideoGenerationInput): Promise<VideoGenerationResult>
}
