import { z } from "zod"

const CapabilityVersionSchema = z.number().int().safe().positive()

export const CapabilityRequirementSchema = z
  .object({
    id: z.string().min(1),
    version: CapabilityVersionSchema,
  })
  .strict()

export const CapabilityProviderDescriptorSchema = CapabilityRequirementSchema.extend({
  providerId: z.string().min(1),
})

function hasUniqueCapabilityProviders(
  values: readonly { id: string; version: number; providerId: string }[],
): boolean {
  const tuples = values.map((value) => `${value.id}\u0000${value.version}\u0000${value.providerId}`)
  return new Set(tuples).size === tuples.length
}

const EntrySchema = z
  .object({
    frontend: z.string().min(1),
    backend: z.string().min(1),
    providers: z.string().min(1).optional(),
  })
  .strict()

const PaneSchema = z
  .object({
    minWidth: z.number().finite().nonnegative().optional(),
    minHeight: z.number().finite().nonnegative().optional(),
    width: z.number().finite().nonnegative().optional(),
    scrollable: z.boolean().optional(),
  })
  .strict()

const WorkbenchPanesSchema = z
  .object({
    left: PaneSchema.optional(),
    center: PaneSchema.optional(),
  })
  .strict()

const WorkbenchContributionSchema = z
  .object({
    id: z.string().min(1).optional(),
    lens: z.string().min(1).optional(),
    icon: z.string().min(1).optional(),
    position: z.number().finite().optional(),
    panelSize: z.enum(["sm", "md", "lg"]).optional(),
    surface: z.string().min(1).optional(),
    panes: WorkbenchPanesSchema,
    bus: z.object({ surfaceId: z.string().min(1) }).strict().optional(),
    matchProduces: z.array(z.string().min(1)).optional(),
    hidden: z.boolean().optional(),
    preferredAgent: z.string().min(1).optional(),
  })
  .strict()

export const ToolDescriptorSchema = z
  .object({
    id: z.string().min(1),
    title: z.string().min(1).optional(),
    description: z.string().min(1).optional(),
    inputSchema: z.string().min(1),
    outputSchema: z.string().min(1).optional(),
    permissions: z.array(z.string().min(1)).optional(),
    exposedToAI: z.boolean().optional(),
    requireConfirm: z.enum(["always", "destructive", "never"]).optional(),
    confirmMessage: z.string().min(1).optional(),
    requiresCapabilities: z.array(CapabilityRequirementSchema).optional(),
  })
  .strict()

export type ToolDescriptor = z.infer<typeof ToolDescriptorSchema>

export const WorkbenchManifestSchema = z
  .object({
    kind: z.literal("workbench"),
    id: z.string().min(1),
    version: z.string().min(1),
    displayName: z.string().min(1),
    icon: z.string().min(1).optional(),
    entry: EntrySchema,
    provides: z
      .object({
        workbench: WorkbenchContributionSchema,
        capabilities: z
          .array(CapabilityProviderDescriptorSchema)
          .refine(hasUniqueCapabilityProviders, "Capability provider declarations must be unique")
          .optional(),
      })
      .strict(),
    permissions: z.array(z.string().min(1)),
    requestedEnv: z.array(z.string().min(1)),
    tools: z.array(ToolDescriptorSchema),
  })
  .strict()
  .superRefine((manifest, context) => {
    if (
      manifest.provides.capabilities?.length &&
      manifest.entry.providers === undefined
    ) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["entry", "providers"],
        message: "entry.providers is required when provides.capabilities is declared",
      })
    }
  })

export type WorkbenchManifest = z.infer<typeof WorkbenchManifestSchema>
