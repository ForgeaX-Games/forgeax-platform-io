import type {
  CapabilityProviderDescriptor,
  CapabilityRequirement,
  CapabilitySelection,
} from "../contracts/capability.js"
import { WorkbenchError } from "../contracts/error.js"

export interface CapabilityRegistration<TProvider = unknown> {
  readonly extensionId: string
  readonly capability: CapabilityProviderDescriptor
  readonly provider: TProvider
}

interface RegisteredCapability<TProvider = unknown> extends CapabilityRegistration<TProvider> {}

const requirementKey = (value: CapabilityRequirement): string =>
  `${value.id}@${String(value.version)}`

const providerKey = (value: CapabilityProviderDescriptor): string =>
  `${requirementKey(value)}#${value.providerId}`

function capabilityError(code: string, message: string): WorkbenchError {
  return new WorkbenchError({ code, target: "host", message, retryable: false })
}

/**
 * Host-owned registration and deterministic selection for extension-provided
 * capabilities. Providers stay opaque to this registry.
 */
export class CapabilityRegistry<TProvider = unknown> {
  readonly #registrations = new Map<string, RegisteredCapability<TProvider>>()
  readonly #selections = new Map<string, CapabilitySelection>()

  constructor(selections: readonly CapabilitySelection[] = []) {
    for (const selection of selections) this.select(selection)
  }

  register(registration: CapabilityRegistration<TProvider>): void {
    const key = providerKey(registration.capability)
    const existing = this.#registrations.get(key)
    if (existing !== undefined) {
      if (
        existing.extensionId === registration.extensionId &&
        existing.provider === registration.provider
      ) return
      throw capabilityError(
        "capability_provider_conflict",
        "A different extension provider is already registered for this capability",
      )
    }
    this.#registrations.set(key, registration)
  }

  select(selection: CapabilitySelection): void {
    const key = requirementKey(selection)
    const existing = this.#selections.get(key)
    if (existing !== undefined && existing.providerId !== selection.providerId) {
      throw capabilityError(
        "capability_selection_conflict",
        "A different provider is already selected for this capability",
      )
    }
    this.#selections.set(key, selection)
  }

  require(requirement: CapabilityRequirement): TProvider {
    const matching = [...this.#registrations.values()].filter(
      (registration) => requirementKey(registration.capability) === requirementKey(requirement),
    )
    const selection = this.#selections.get(requirementKey(requirement))
    if (selection !== undefined) {
      const selected = matching.find(
        (registration) => registration.capability.providerId === selection.providerId,
      )
      if (selected !== undefined) return selected.provider
      throw capabilityError(
        "capability_selected_provider_unavailable",
        "The selected capability provider is not registered",
      )
    }
    if (matching.length === 1) return matching[0]!.provider
    if (matching.length === 0) {
      throw capabilityError("capability_not_found", "No provider is registered for this capability")
    }
    throw capabilityError(
      "capability_ambiguous",
      "Multiple providers are registered for this capability without a selection",
    )
  }

  /** Resolves only a product-selected provider; implicit singleton fallback is not allowed here. */
  requireSelected(requirement: CapabilityRequirement): TProvider {
    const selection = this.#selections.get(requirementKey(requirement))
    if (selection === undefined) {
      throw capabilityError(
        "capability_selection_missing",
        "No provider is selected for this capability",
      )
    }
    return this.requireProvider(requirement, selection.providerId)
  }

  selectedProviderId(requirement: CapabilityRequirement): string | undefined {
    return this.#selections.get(requirementKey(requirement))?.providerId
  }

  /** Resolves the exact provider recorded in a durable receipt. */
  requireProvider(
    requirement: CapabilityRequirement,
    providerId: string,
  ): TProvider {
    const registration = this.#registrations.get(providerKey({
      ...requirement,
      providerId,
    }))
    if (registration === undefined) {
      throw capabilityError(
        "capability_provider_not_found",
        "The recorded capability provider is not registered",
      )
    }
    return registration.provider
  }
}
