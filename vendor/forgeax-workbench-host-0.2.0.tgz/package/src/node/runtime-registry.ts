import { createHash, randomBytes } from "node:crypto"
import { dirname, isAbsolute, join, relative, sep } from "node:path"

import type { ExtensionManifest } from "./merge-manifest.js"
import type { ScannedExtension } from "./scan-package.js"

export interface RuntimeDescriptor {
  readonly runtimeId: string
  readonly manifest: ExtensionManifest
  readonly source: ScannedExtension
}

export interface BrowserCatalogEntry {
  readonly extensionId: string
  readonly runtimeId: string
  readonly title: string
  readonly icon: string | undefined
  readonly surface: string | undefined
  readonly panes: ExtensionManifest["provides"]["workbench"]["panes"]
  readonly runtimeUrl: string
}

export interface RuntimeStaticProjection {
  readonly root: string
  readonly entry: string
  readonly deniedRelativePaths: readonly string[]
  readonly deniedFileExtensions: readonly string[]
  readonly deniedFileNames: readonly string[]
  readonly deniedFilePrefixes: readonly string[]
}

function isWithin(root: string, candidate: string): boolean {
  const path = relative(root, candidate)
  return path === "" || (!isAbsolute(path) && path !== ".." && !path.startsWith(`..${sep}`))
}

/** Projects only the frontend web root and explicitly excludes an in-tree backend. */
export function runtimeStaticProjection(source: ScannedExtension): RuntimeStaticProjection {
  const frontendDirectory = dirname(source.frontendEntry)
  const root = join(source.packageRoot, frontendDirectory)
  const entry = relative(frontendDirectory, source.frontendEntry)
  const deniedRelativePaths: string[] = []
  const manifest = join(source.packageRoot, "forgeax-extension.json")
  if (isWithin(root, manifest)) deniedRelativePaths.push(relative(root, manifest))
  const backend = join(source.packageRoot, source.backendEntry)
  if (isWithin(root, backend)) {
    const backendRelative = relative(root, backend)
    const backendDirectory = dirname(backendRelative)
    deniedRelativePaths.push(backendDirectory === "." ? backendRelative : backendDirectory)
  }
  return {
    root,
    entry: entry.split(sep).join("/"),
    deniedRelativePaths: deniedRelativePaths.map((path) => path.split(sep).join("/")),
    deniedFileExtensions: [".map", ".ts", ".tsx", ".mts", ".cts"],
    deniedFileNames: [
      "forgeax-extension.json",
      "package.json",
      "package-lock.json",
      "npm-shrinkwrap.json",
      "pnpm-lock.yaml",
      "yarn.lock",
      "bun.lock",
      "bun.lockb",
      "deno.lock",
    ],
    deniedFilePrefixes: [
      "tsconfig.",
      "vite.config.",
      "vitest.config.",
      "webpack.config.",
      "rollup.config.",
      "esbuild.config.",
    ],
  }
}

export class RuntimeRegistry {
  readonly #salt = randomBytes(32).toString("hex")
  readonly #byRuntimeId = new Map<string, RuntimeDescriptor>()
  readonly #runtimeByExtensionId = new Map<string, string>()

  register(source: ScannedExtension): RuntimeDescriptor {
    const existingRuntimeId = this.#runtimeByExtensionId.get(source.manifest.id)
    const existing = existingRuntimeId
      ? this.#byRuntimeId.get(existingRuntimeId)
      : undefined
    if (existing && existing.manifest.version === source.manifest.version) {
      const descriptor = { ...existing, source, manifest: source.manifest }
      this.#byRuntimeId.set(descriptor.runtimeId, descriptor)
      return descriptor
    }

    if (existingRuntimeId) {
      this.#byRuntimeId.delete(existingRuntimeId)
    }

    const runtimeId = this.#runtimeIdFor(source.manifest)
    const descriptor: RuntimeDescriptor = {
      runtimeId,
      manifest: source.manifest,
      source,
    }
    this.#byRuntimeId.set(runtimeId, descriptor)
    this.#runtimeByExtensionId.set(source.manifest.id, runtimeId)
    return descriptor
  }

  get(runtimeId: string): RuntimeDescriptor | undefined {
    return this.#byRuntimeId.get(runtimeId)
  }

  /** Returns the host-only descriptors currently registered in this process. */
  entries(): RuntimeDescriptor[] {
    return [...this.#byRuntimeId.values()]
  }

  /** Lists only runtimes that declare a host capability provider module. */
  providerEntries(): RuntimeDescriptor[] {
    return this.entries().filter((descriptor) => (
      (descriptor.manifest.provides.capabilities?.length ?? 0) > 0
    ))
  }

  catalog(): BrowserCatalogEntry[] {
    return [...this.#byRuntimeId.values()].map((descriptor) => {
      const projection = runtimeStaticProjection(descriptor.source)
      return {
        extensionId: descriptor.manifest.id,
        runtimeId: descriptor.runtimeId,
        title: descriptor.manifest.displayName,
        icon: descriptor.manifest.icon,
        surface: descriptor.manifest.provides.workbench.surface,
        panes: descriptor.manifest.provides.workbench.panes,
        runtimeUrl: `runtime/${descriptor.runtimeId}/${projection.entry}`,
      }
    })
  }

  #runtimeIdFor(manifest: ExtensionManifest): string {
    const digest = createHash("sha256")
      .update(`${this.#salt}\0${manifest.id}\0${manifest.version}`)
      .digest("hex")
      .slice(0, 16)
    return `rt_${digest}`
  }
}
