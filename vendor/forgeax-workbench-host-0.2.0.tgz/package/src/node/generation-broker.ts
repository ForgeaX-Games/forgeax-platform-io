import type {
  GenerationJob,
  MediaAsset,
  MediaCapability,
  ProviderExecutionContext,
  ProviderMediaOutput,
  ProviderTaskStatus,
  VideoGenerationInput,
  VideoGenerationProviderV1,
  VideoGenerationResult,
} from "../contracts/index.js"
import { ServiceRequestError, WorkbenchError } from "../contracts/index.js"
import { CapabilityRegistry } from "./capability-registry.js"
import {
  GenerationReceiptStore,
  type GenerationReceiptV1,
} from "./generation-receipt-store.js"
import { ServiceBindingRegistry } from "./service-binding-registry.js"

const videoCapability = { id: "media.video.generate", version: 1 } as const
const terminalStatuses = new Set(["succeeded", "failed", "cancelled"])
const allowedVideoContentTypes = [
  "video/mp4",
] as const

class ProviderOutputValidationError extends Error {
  constructor() {
    super("Provider output content type is not allowed")
    this.name = "ProviderOutputValidationError"
  }
}

export interface GenerationBrokerOptions {
  readonly receipts: GenerationReceiptStore
  readonly capabilities: CapabilityRegistry<VideoGenerationProviderV1>
  readonly services: ServiceBindingRegistry
  readonly media: MediaCapability
  /** Provider identity selected by product configuration for the video capability. */
  readonly providerId: string
  readonly pollIntervalMs?: number
  readonly synchronousTimeoutMs?: number
  readonly now?: () => Date
  readonly sleep?: (milliseconds: number) => Promise<void>
}

function isTerminal(status: GenerationJob["status"]): boolean {
  return terminalStatuses.has(status)
}

function errorDetails(code: string, message: string, retryable: boolean): GenerationJob["error"] {
  return { code, message, retryable }
}

function isKnownNotReachedUpstream(error: unknown): boolean {
  if (error instanceof ServiceRequestError) return error.requestReachedUpstream === false
  return typeof error === "object" && error !== null &&
    (error as { requestReachedUpstream?: unknown }).requestReachedUpstream === false
}

/**
 * Drives the selected asynchronous video provider while keeping upstream task
 * ids and output locators inside a game-scoped receipt. Browser callers only
 * ever receive host-owned GenerationJob and MediaAsset values.
 */
export class GenerationBroker {
  readonly #receipts: GenerationReceiptStore
  readonly #capabilities: CapabilityRegistry<VideoGenerationProviderV1>
  readonly #services: ServiceBindingRegistry
  readonly #media: MediaCapability
  readonly #providerId: string
  readonly #pollIntervalMs: number
  readonly #synchronousTimeoutMs: number
  readonly #now: () => Date
  readonly #sleep: (milliseconds: number) => Promise<void>
  readonly #ticks = new Map<string, Promise<GenerationJob>>()
  readonly #background = new Map<string, Promise<void>>()

  constructor(options: GenerationBrokerOptions) {
    this.#receipts = options.receipts
    this.#capabilities = options.capabilities
    this.#services = options.services
    this.#media = options.media
    this.#providerId = options.providerId
    this.#pollIntervalMs = options.pollIntervalMs ?? 1_000
    this.#synchronousTimeoutMs = options.synchronousTimeoutMs ?? 5_000
    this.#now = options.now ?? (() => new Date())
    this.#sleep = options.sleep ?? ((milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)))
  }

  async start(gameId: string, input: VideoGenerationInput): Promise<GenerationJob> {
    this.#configuredProvider()
    const job = await this.#receipts.start(gameId, { providerId: this.#providerId, input })
    if (!isTerminal(job.status)) this.#runInBackground(gameId, job.jobId)
    return job
  }

  async get(gameId: string, jobId: string): Promise<GenerationJob> {
    const job = await this.#receipts.get(gameId, jobId)
    if (!isTerminal(job.status)) this.#runInBackground(gameId, jobId)
    return job
  }

  async cancel(gameId: string, jobId: string): Promise<void> {
    const transition = await this.#receipts.updateIf(gameId, jobId, (receipt) => (
      !isTerminal(receipt.job.status)
    ), (receipt) => ({
      ...receipt,
      job: {
        ...receipt.job,
        status: "cancelled",
        updatedAt: this.#now().toISOString(),
        error: undefined,
      },
    }))
    if (transition.updated && transition.receipt.providerTaskId !== undefined) {
      try {
        await this.#provider(transition.receipt).cancel?.(
          this.#context(gameId, transition.receipt.job.jobId),
          transition.receipt.providerTaskId,
        )
      } catch {
        // Provider cancellation is best effort; the durable terminal state wins.
      }
    }
  }

  async tick(gameId: string, jobId: string): Promise<GenerationJob> {
    const key = `${gameId}\u0000${jobId}`
    const existing = this.#ticks.get(key)
    if (existing !== undefined) return existing
    const work = this.#tick(gameId, jobId).finally(() => this.#ticks.delete(key))
    this.#ticks.set(key, work)
    return work
  }

  async recover(gameId: string): Promise<readonly GenerationJob[]> {
    const receipts = await this.#receipts.list(gameId)
    return Promise.all(receipts
      .filter((receipt) => (
        receipt.job.status === "created" ||
        receipt.job.status === "submitting" ||
        receipt.job.status === "polling" ||
        receipt.job.status === "output_pending_import"
      ))
      .map(async (receipt) => {
        if (receipt.job.status === "submitting") {
          return this.tick(gameId, receipt.job.jobId)
        }
        const job = await this.tick(gameId, receipt.job.jobId)
        if (!isTerminal(job.status)) this.#runInBackground(gameId, receipt.job.jobId)
        return job
      }))
  }

  async generateVideo(gameId: string, input: VideoGenerationInput): Promise<VideoGenerationResult> {
    const job = await this.start(gameId, input)
    const background = this.#runInBackground(gameId, job.jobId)
    const completed = await Promise.race([
      background.then(async () => this.get(gameId, job.jobId)),
      this.#sleep(this.#synchronousTimeoutMs).then(() => null),
    ])
    if (completed !== null && completed.status === "succeeded") {
      return { assets: [...(completed.assets ?? [])], metadata: { jobId: job.jobId } }
    }
    return { assets: [], metadata: { jobId: job.jobId } }
  }

  async #tick(gameId: string, jobId: string): Promise<GenerationJob> {
    const receipt = await this.#receipts.read(gameId, jobId)
    if (isTerminal(receipt.job.status)) return receipt.job
    if (receipt.job.status === "submitting") {
      return this.#failUnknownSubmission(gameId, jobId)
    }
    if (receipt.job.status === "created") {
      return this.#submit(gameId, receipt)
    }
    return this.#query(gameId, receipt)
  }

  async #submit(gameId: string, receipt: GenerationReceiptV1): Promise<GenerationJob> {
    const transition = await this.#receipts.updateIf(gameId, receipt.job.jobId, (current) => (
      current.job.status === "created"
    ), (current) => ({
      ...current,
      submitAttempts: current.submitAttempts + 1,
      job: {
        ...current.job,
        status: "submitting",
        updatedAt: this.#now().toISOString(),
        error: undefined,
      },
    }))
    const submitting = transition.receipt
    if (!transition.updated) return submitting.job
    try {
      const submitted = await this.#provider(submitting).submit(
        this.#context(gameId, submitting.job.jobId),
        submitting.request,
      )
      if (submitted.providerTaskId.length === 0) {
        return this.#failUnknownSubmission(gameId, submitting.job.jobId)
      }
      const persisted = await this.#receipts.updateIf(gameId, submitting.job.jobId, (current) => (
        current.job.status === "submitting"
      ), (current) => ({
        ...current,
        providerTaskId: submitted.providerTaskId,
        job: {
          ...current.job,
          status: "polling",
          updatedAt: this.#now().toISOString(),
          error: undefined,
        },
      }))
      if (!persisted.updated) return persisted.receipt.job
      return this.#query(gameId, persisted.receipt)
    } catch (error) {
      if (isKnownNotReachedUpstream(error)) {
        return this.#setJob(gameId, submitting.job.jobId, ["submitting"], (job) => ({
          ...job,
          status: "created",
          updatedAt: this.#now().toISOString(),
          error: errorDetails("provider_submission_retryable", "Provider submission can be retried", true),
        }))
      }
      return this.#failUnknownSubmission(gameId, submitting.job.jobId, ["submitting"])
    }
  }

  async #query(gameId: string, receipt: GenerationReceiptV1): Promise<GenerationJob> {
    if (receipt.providerTaskId === undefined) {
      return this.#failUnknownSubmission(gameId, receipt.job.jobId, ["polling", "output_pending_import"])
    }
    const queryTransition = await this.#receipts.updateIf(gameId, receipt.job.jobId, (current) => (
      current.job.status === receipt.job.status
    ), (current) => ({
      ...current,
      queryAttempts: current.queryAttempts + 1,
    }))
    const queried = queryTransition.receipt
    if (!queryTransition.updated) return queried.job
    let result: ProviderTaskStatus
    try {
      result = await this.#provider(queried).query(
        this.#context(gameId, queried.job.jobId),
        queried.providerTaskId!,
      )
    } catch (error) {
      return this.#setJob(gameId, queried.job.jobId, [queried.job.status], (job) => ({
        ...job,
        updatedAt: this.#now().toISOString(),
        error: errorDetails("provider_query_retryable", "Provider status cannot be read yet", true),
      }))
    }
    if (result.status === "polling") {
      return this.#setJob(gameId, queried.job.jobId, [queried.job.status], (job) => ({
        ...job,
        status: "polling",
        ...(result.progress === undefined ? {} : { progress: result.progress }),
        updatedAt: this.#now().toISOString(),
        error: undefined,
      }))
    }
    if (result.status === "failed") {
      return this.#setJob(gameId, queried.job.jobId, [queried.job.status], (job) => ({
        ...job,
        status: "failed",
        updatedAt: this.#now().toISOString(),
        error: errorDetails(
          "provider_generation_failed",
          "Provider reported that video generation failed",
          result.retryable,
        ),
      }))
    }
    if (result.status === "cancelled") {
      return this.#setJob(gameId, queried.job.jobId, [queried.job.status], (job) => ({
        ...job,
        status: "cancelled",
        updatedAt: this.#now().toISOString(),
        error: undefined,
      }))
    }
    const pending = await this.#setJob(gameId, queried.job.jobId, [queried.job.status], (job) => ({
      ...job,
      status: "output_pending_import",
      updatedAt: this.#now().toISOString(),
      error: undefined,
    }))
    if (pending.status !== "output_pending_import") return pending
    return this.#importOutputs(gameId, queried, result.outputs)
  }

  async #importOutputs(
    gameId: string,
    receipt: GenerationReceiptV1,
    outputs: readonly ProviderMediaOutput[],
  ): Promise<GenerationJob> {
    try {
      const assets: MediaAsset[] = []
      for (const [index, output] of outputs.entries()) {
        if (!allowedVideoContentTypes.includes(output.contentType as typeof allowedVideoContentTypes[number])) {
          throw new ProviderOutputValidationError()
        }
        const body = await this.#services.download(output.serviceId, gameId, {
          locator: output.locator,
          maxBytes: 512 * 1024 * 1024,
          allowedContentTypes: allowedVideoContentTypes,
        })
        if (!allowedVideoContentTypes.includes(body.contentType as typeof allowedVideoContentTypes[number])) {
          throw new ProviderOutputValidationError()
        }
        assets.push(await this.#media.put(gameId, {
          filename: output.filename,
          contentType: body.contentType,
          bytes: body.bytes,
          idempotencyKey: `generation:${receipt.job.jobId}:${String(index)}`,
          metadata: {
            capabilityId: videoCapability.id,
            providerId: receipt.providerId,
            jobId: receipt.job.jobId,
          },
        }))
      }
      return this.#setJob(gameId, receipt.job.jobId, ["output_pending_import"], (job) => ({
        ...job,
        status: "succeeded",
        assets,
        updatedAt: this.#now().toISOString(),
        error: undefined,
      }))
    } catch (error) {
      if (error instanceof ProviderOutputValidationError) {
        return this.#setJob(gameId, receipt.job.jobId, ["output_pending_import"], (job) => ({
          ...job,
          status: "failed",
          updatedAt: this.#now().toISOString(),
          error: errorDetails(
            "provider_output_content_type_invalid",
            "Provider output content type is not allowed",
            false,
          ),
        }))
      }
      return this.#setJob(gameId, receipt.job.jobId, ["output_pending_import"], (job) => ({
        ...job,
        status: "output_pending_import",
        updatedAt: this.#now().toISOString(),
        error: errorDetails("generation_import_retryable", "Video output import can be retried", true),
      }))
    }
  }

  #configuredProvider(): VideoGenerationProviderV1 {
    const configured = this.#capabilities.requireProvider(videoCapability, this.#providerId)
    if (this.#capabilities.require(videoCapability) !== configured) {
      throw new WorkbenchError({
        code: "generation_provider_selection_mismatch",
        target: "host",
        message: "Configured video generation provider is not selected",
        retryable: false,
      })
    }
    return configured
  }

  #provider(receipt: GenerationReceiptV1): VideoGenerationProviderV1 {
    return this.#capabilities.requireProvider(videoCapability, receipt.providerId)
  }

  #context(gameId: string, jobId: string): ProviderExecutionContext {
    return {
      gameId,
      traceId: `generation:${jobId}`,
      media: this.#media,
      services: this.#services.forGame(gameId),
    }
  }

  async #failUnknownSubmission(
    gameId: string,
    jobId: string,
    expectedStatuses: readonly GenerationJob["status"][] = ["submitting"],
  ): Promise<GenerationJob> {
    return this.#setJob(gameId, jobId, expectedStatuses, (job) => ({
      ...job,
      status: "failed",
      updatedAt: this.#now().toISOString(),
      error: errorDetails(
        "provider_submission_unknown",
        "Provider submission outcome is unknown and will not be retried",
        false,
      ),
    }))
  }

  async #setJob(
    gameId: string,
    jobId: string,
    expectedStatuses: readonly GenerationJob["status"][],
    operation: (job: GenerationJob) => GenerationJob,
  ): Promise<GenerationJob> {
    const transition = await this.#receipts.updateIf(gameId, jobId, (current) => (
      expectedStatuses.includes(current.job.status)
    ), (current) => ({
      ...current,
      job: operation(current.job),
    }))
    return transition.receipt.job
  }

  #runInBackground(gameId: string, jobId: string): Promise<void> {
    const key = `${gameId}\u0000${jobId}`
    const existing = this.#background.get(key)
    if (existing !== undefined) return existing
    const work = (async () => {
      for (;;) {
        const job = await this.tick(gameId, jobId)
        if (isTerminal(job.status)) return
        await this.#sleep(this.#pollIntervalMs)
      }
    })().catch(() => undefined).finally(() => this.#background.delete(key))
    this.#background.set(key, work)
    return work
  }
}
