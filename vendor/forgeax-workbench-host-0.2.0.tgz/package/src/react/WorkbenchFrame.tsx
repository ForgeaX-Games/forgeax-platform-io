import {
  createElement,
  useCallback,
  useEffect,
  useRef,
  type IframeHTMLAttributes,
  type SyntheticEvent,
} from "react"

import {
  attachWorkbenchFrame,
  type WorkbenchFrameController,
} from "../browser/frame-controller.js"
import type { WorkbenchSessionContext } from "../contracts/session.js"

export interface WorkbenchFrameProps
  extends Omit<IframeHTMLAttributes<HTMLIFrameElement>, "src" | "ref"> {
  readonly runtimeUrl: string
  readonly context: WorkbenchSessionContext
  readonly onController?: (controller: WorkbenchFrameController | undefined) => void
}

/** A lifecycle-safe iframe projection of one already-resolved Workbench runtime. */
export function WorkbenchFrame({
  runtimeUrl,
  context,
  onController,
  onLoad,
  sandbox = "allow-scripts",
  ...iframeProps
}: WorkbenchFrameProps) {
  const controllerRef = useRef<WorkbenchFrameController | undefined>(undefined)
  const onControllerRef = useRef(onController)
  const onLoadRef = useRef(onLoad)
  const loadedRef = useRef(false)
  onControllerRef.current = onController
  onLoadRef.current = onLoad
  const capabilityKey = context.capabilities.join("\u0000")
  const attachController = useCallback(
    (iframe: HTMLIFrameElement) => {
      controllerRef.current?.close()
      controllerRef.current = undefined
      onControllerRef.current?.(undefined)
      if (iframe.contentWindow === null) return
      const opaqueSandbox = !sandbox.split(/\s+/u).includes("allow-same-origin")
      const origin = opaqueSandbox
        ? "null"
        : new URL(runtimeUrl, window.location.href).origin
      const controller = attachWorkbenchFrame({
        frameWindow: iframe.contentWindow,
        ownerWindow: window,
        origin,
        ...(opaqueSandbox ? { targetOrigin: "*" } : {}),
        context,
      })
      controllerRef.current = controller
      onControllerRef.current?.(controller)
    },
    [
      runtimeUrl,
      context.extensionId,
      context.runtimeId,
      context.gameId,
      context.locale,
      context.theme,
      context.endpoints.toolCall,
      context.endpoints.gamePackage,
      context.endpoints.extensionApi,
      context.endpoints.gameVersions,
      context.endpoints.gameComponents,
      capabilityKey,
      sandbox,
    ],
  )
  const callbackRef = useCallback(
    (iframe: HTMLIFrameElement | null) => {
      if (iframe === null) {
        controllerRef.current?.close()
        controllerRef.current = undefined
        onControllerRef.current?.(undefined)
        return
      }
      attachController(iframe)
    },
    [attachController],
  )
  const handleLoad = useCallback(
    (event: SyntheticEvent<HTMLIFrameElement>) => {
      if (loadedRef.current) attachController(event.currentTarget)
      loadedRef.current = true
      onLoadRef.current?.(event)
    },
    [attachController],
  )

  useEffect(
    () => () => {
      controllerRef.current?.close()
      controllerRef.current = undefined
      onControllerRef.current?.(undefined)
    },
    [],
  )

  return createElement("iframe", {
    ...iframeProps,
    ref: callbackRef,
    src: runtimeUrl,
    sandbox,
    onLoad: handleLoad,
  })
}
