import type { Plugin, ViteDevServer } from "vite"

import { createWorkbenchHttpHandler, isBodylessStatus, stripMountPrefix, type WorkbenchHttpHost } from "../http/common.js"

async function readRaw(request: AsyncIterable<Uint8Array | string>): Promise<Uint8Array> {
  const chunks: Uint8Array[] = []; let size = 0
  for await (const chunk of request) { const bytes = typeof chunk === "string" ? new TextEncoder().encode(chunk) : chunk; size += bytes.byteLength; if (size > 1_048_576) throw new Error("Request body is too large"); chunks.push(bytes) }
  return new Uint8Array(Buffer.concat(chunks))
}

/** Development-only raw middleware projection for an already-created complete host. */
export function createViteWorkbenchPlugin(host: WorkbenchHttpHost, options: { readonly base?: string } = {}): Plugin {
  if (process.env.NODE_ENV === "production") throw new Error("The workbench Vite adapter is development-only")
  if (!host) throw new TypeError("An already-created workbench host is required")
  const base = options.base ?? "/__workbench__/v1"; const handler = createWorkbenchHttpHandler(host)
  return { name: "forgeax-workbench-host", configureServer(server: ViteDevServer) {
    server.middlewares.use(base, async (request, reply) => {
      let body: Uint8Array
      try { body = await readRaw(request) } catch { reply.statusCode = 413; reply.setHeader("content-type", "application/json; charset=utf-8"); reply.end(JSON.stringify({ ok: false, error: { code: "request_too_large", target: "http", message: "Request body is too large", retryable: false } })); return }
      const response = await handler({ method: request.method ?? "GET", path: stripMountPrefix(request.url ?? "/", base), headers: request.headers as Record<string, string | undefined>, body })
      reply.statusCode = response.status
      for (const [name, value] of Object.entries(response.headers)) reply.setHeader(name, value)
      reply.end(request.method === "HEAD" || isBodylessStatus(response.status) ? undefined : response.body)
    })
  } }
}
