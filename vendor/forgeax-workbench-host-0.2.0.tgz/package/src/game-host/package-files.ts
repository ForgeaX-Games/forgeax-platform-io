export const PACKAGE_FILES = [
  "project.json",
  "blueprint.json",
  "assets/manifest.json",
] as const

export type PackageFile = (typeof PACKAGE_FILES)[number]

export type GamePackage = Readonly<Record<string, unknown>> & {
  readonly project: unknown
  readonly blueprint: unknown
  readonly assetsManifest: unknown
}

export type GamePackageState = "uninitialized" | "initialized" | "inconsistent"

export interface GamePackageStatus {
  readonly state: GamePackageState
}

const PACKAGE_KEYS = {
  "project.json": "project",
  "blueprint.json": "blueprint",
  "assets/manifest.json": "assetsManifest",
} as const

/** Converts the public package object into the three paths owned by this host. */
export function packageFiles(value: GamePackage): ReadonlyMap<PackageFile, unknown> {
  return new Map(
    PACKAGE_FILES.map((file) => [file, value[PACKAGE_KEYS[file]]] as const),
  )
}

/** Builds a public package object from exactly the three owned JSON values. */
export function gamePackageFromFiles(
  files: ReadonlyMap<PackageFile, unknown>,
): GamePackage {
  return {
    project: files.get("project.json"),
    blueprint: files.get("blueprint.json"),
    assetsManifest: files.get("assets/manifest.json"),
  }
}

/** Rejects extension seed data that cannot describe the complete owned package. */
export function gamePackageFromSeed(seed: Record<string, unknown>): GamePackage {
  if (
    !Object.hasOwn(seed, "project") ||
    !Object.hasOwn(seed, "blueprint") ||
    !Object.hasOwn(seed, "assetsManifest")
  ) {
    throw new TypeError(
      "Game package seed must include project, blueprint, and assetsManifest",
    )
  }
  return {
    project: seed.project,
    blueprint: seed.blueprint,
    assetsManifest: seed.assetsManifest,
  }
}
